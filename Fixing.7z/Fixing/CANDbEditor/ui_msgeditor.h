/********************************************************************************
** Form generated from reading UI file 'msgeditor.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MSGEDITOR_H
#define UI_MSGEDITOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MsgEditor
{
public:
    QGridLayout *gridLayout;
    QDialogButtonBox *buttonBox;
    QTabWidget *m_tabWidgetMsg;
    QWidget *Definition;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout;
    QLabel *MsgName;
    QLabel *MsgType;
    QLabel *MsgID;
    QLabel *MsgDLC;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *m_Name;
    QComboBox *m_Type;
    QLineEdit *m_ID;
    QLineEdit *m_DLC;
    QSpacerItem *verticalSpacer_2;
    QWidget *Signal;
    QGridLayout *gridLayout_2;
    QTableWidget *tableWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_2;
    QWidget *Layout;
    QGridLayout *gridLayout_5;
    QTableWidget *tableWidget_2;
    QWidget *Comment;
    QGridLayout *gridLayout_4;
    QTextEdit *textEdit;

    void setupUi(QDialog *MsgEditor)
    {
        if (MsgEditor->objectName().isEmpty())
            MsgEditor->setObjectName(QStringLiteral("MsgEditor"));
        MsgEditor->resize(860, 370);
        gridLayout = new QGridLayout(MsgEditor);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        buttonBox = new QDialogButtonBox(MsgEditor);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 1, 0, 1, 1);

        m_tabWidgetMsg = new QTabWidget(MsgEditor);
        m_tabWidgetMsg->setObjectName(QStringLiteral("m_tabWidgetMsg"));
        Definition = new QWidget();
        Definition->setObjectName(QStringLiteral("Definition"));
        gridLayout_3 = new QGridLayout(Definition);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer, 0, 2, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        MsgName = new QLabel(Definition);
        MsgName->setObjectName(QStringLiteral("MsgName"));

        verticalLayout->addWidget(MsgName);

        MsgType = new QLabel(Definition);
        MsgType->setObjectName(QStringLiteral("MsgType"));

        verticalLayout->addWidget(MsgType);

        MsgID = new QLabel(Definition);
        MsgID->setObjectName(QStringLiteral("MsgID"));

        verticalLayout->addWidget(MsgID);

        MsgDLC = new QLabel(Definition);
        MsgDLC->setObjectName(QStringLiteral("MsgDLC"));

        verticalLayout->addWidget(MsgDLC);


        gridLayout_3->addLayout(verticalLayout, 0, 0, 1, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        m_Name = new QLineEdit(Definition);
        m_Name->setObjectName(QStringLiteral("m_Name"));

        verticalLayout_2->addWidget(m_Name);

        m_Type = new QComboBox(Definition);
        m_Type->setObjectName(QStringLiteral("m_Type"));

        verticalLayout_2->addWidget(m_Type);

        m_ID = new QLineEdit(Definition);
        m_ID->setObjectName(QStringLiteral("m_ID"));

        verticalLayout_2->addWidget(m_ID);

        m_DLC = new QLineEdit(Definition);
        m_DLC->setObjectName(QStringLiteral("m_DLC"));

        verticalLayout_2->addWidget(m_DLC);


        gridLayout_3->addLayout(verticalLayout_2, 0, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_2, 1, 0, 1, 1);

        m_tabWidgetMsg->addTab(Definition, QString());
        Signal = new QWidget();
        Signal->setObjectName(QStringLiteral("Signal"));
        gridLayout_2 = new QGridLayout(Signal);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        tableWidget = new QTableWidget(Signal);
        if (tableWidget->columnCount() < 6)
            tableWidget->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));

        gridLayout_2->addWidget(tableWidget, 0, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButton_2 = new QPushButton(Signal);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);

        pushButton = new QPushButton(Signal);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        gridLayout_2->addLayout(horizontalLayout, 1, 0, 1, 1);

        m_tabWidgetMsg->addTab(Signal, QString());
        Layout = new QWidget();
        Layout->setObjectName(QStringLiteral("Layout"));
        gridLayout_5 = new QGridLayout(Layout);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        tableWidget_2 = new QTableWidget(Layout);
        if (tableWidget_2->columnCount() < 8)
            tableWidget_2->setColumnCount(8);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(2, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(3, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(4, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(5, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(6, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(7, __qtablewidgetitem13);
        if (tableWidget_2->rowCount() < 8)
            tableWidget_2->setRowCount(8);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(0, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(1, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(2, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(3, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(4, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(5, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(6, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(7, __qtablewidgetitem21);
        tableWidget_2->setObjectName(QStringLiteral("tableWidget_2"));

        gridLayout_5->addWidget(tableWidget_2, 0, 0, 1, 1);

        m_tabWidgetMsg->addTab(Layout, QString());
        Comment = new QWidget();
        Comment->setObjectName(QStringLiteral("Comment"));
        gridLayout_4 = new QGridLayout(Comment);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        textEdit = new QTextEdit(Comment);
        textEdit->setObjectName(QStringLiteral("textEdit"));

        gridLayout_4->addWidget(textEdit, 0, 0, 1, 1);

        m_tabWidgetMsg->addTab(Comment, QString());

        gridLayout->addWidget(m_tabWidgetMsg, 0, 0, 1, 1);


        retranslateUi(MsgEditor);
        QObject::connect(buttonBox, SIGNAL(accepted()), MsgEditor, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), MsgEditor, SLOT(reject()));

        m_tabWidgetMsg->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MsgEditor);
    } // setupUi

    void retranslateUi(QDialog *MsgEditor)
    {
        MsgEditor->setWindowTitle(QApplication::translate("MsgEditor", "Dialog", Q_NULLPTR));
#ifndef QT_NO_ACCESSIBILITY
        Definition->setAccessibleName(QApplication::translate("MsgEditor", "Definition", Q_NULLPTR));
#endif // QT_NO_ACCESSIBILITY
#ifndef QT_NO_ACCESSIBILITY
        Definition->setAccessibleDescription(QString());
#endif // QT_NO_ACCESSIBILITY
        MsgName->setText(QApplication::translate("MsgEditor", "Name", Q_NULLPTR));
        MsgType->setText(QApplication::translate("MsgEditor", "Type", Q_NULLPTR));
        MsgID->setText(QApplication::translate("MsgEditor", "ID", Q_NULLPTR));
        MsgDLC->setText(QApplication::translate("MsgEditor", "DLC", Q_NULLPTR));
        m_Type->clear();
        m_Type->insertItems(0, QStringList()
         << QApplication::translate("MsgEditor", "CAN Standard", Q_NULLPTR)
         << QApplication::translate("MsgEditor", "CAN Extended", Q_NULLPTR)
        );
        m_tabWidgetMsg->setTabText(m_tabWidgetMsg->indexOf(Definition), QApplication::translate("MsgEditor", "Definition", Q_NULLPTR));
#ifndef QT_NO_ACCESSIBILITY
        Signal->setAccessibleName(QApplication::translate("MsgEditor", "Signal", Q_NULLPTR));
#endif // QT_NO_ACCESSIBILITY
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("MsgEditor", "Signal", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("MsgEditor", "Message", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("MsgEditor", "Startbit", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("MsgEditor", "Length [Bit]", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("MsgEditor", "Byte Order", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("MsgEditor", "Value Type", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MsgEditor", "Add", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MsgEditor", "Remove", Q_NULLPTR));
        m_tabWidgetMsg->setTabText(m_tabWidgetMsg->indexOf(Signal), QApplication::translate("MsgEditor", "Signals", Q_NULLPTR));
#ifndef QT_NO_ACCESSIBILITY
        Layout->setAccessibleName(QApplication::translate("MsgEditor", "urtuyr", Q_NULLPTR));
#endif // QT_NO_ACCESSIBILITY
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_2->horizontalHeaderItem(0);
        ___qtablewidgetitem6->setText(QApplication::translate("MsgEditor", "0", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_2->horizontalHeaderItem(1);
        ___qtablewidgetitem7->setText(QApplication::translate("MsgEditor", "1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_2->horizontalHeaderItem(2);
        ___qtablewidgetitem8->setText(QApplication::translate("MsgEditor", "2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget_2->horizontalHeaderItem(3);
        ___qtablewidgetitem9->setText(QApplication::translate("MsgEditor", "3", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget_2->horizontalHeaderItem(4);
        ___qtablewidgetitem10->setText(QApplication::translate("MsgEditor", "4", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget_2->horizontalHeaderItem(5);
        ___qtablewidgetitem11->setText(QApplication::translate("MsgEditor", "5", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_2->horizontalHeaderItem(6);
        ___qtablewidgetitem12->setText(QApplication::translate("MsgEditor", "6", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_2->horizontalHeaderItem(7);
        ___qtablewidgetitem13->setText(QApplication::translate("MsgEditor", "7", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_2->verticalHeaderItem(0);
        ___qtablewidgetitem14->setText(QApplication::translate("MsgEditor", "0", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_2->verticalHeaderItem(1);
        ___qtablewidgetitem15->setText(QApplication::translate("MsgEditor", "1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget_2->verticalHeaderItem(2);
        ___qtablewidgetitem16->setText(QApplication::translate("MsgEditor", "0", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget_2->verticalHeaderItem(3);
        ___qtablewidgetitem17->setText(QApplication::translate("MsgEditor", "2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget_2->verticalHeaderItem(4);
        ___qtablewidgetitem18->setText(QApplication::translate("MsgEditor", "3", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget_2->verticalHeaderItem(5);
        ___qtablewidgetitem19->setText(QApplication::translate("MsgEditor", "4", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget_2->verticalHeaderItem(6);
        ___qtablewidgetitem20->setText(QApplication::translate("MsgEditor", "5", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget_2->verticalHeaderItem(7);
        ___qtablewidgetitem21->setText(QApplication::translate("MsgEditor", "7", Q_NULLPTR));
        m_tabWidgetMsg->setTabText(m_tabWidgetMsg->indexOf(Layout), QApplication::translate("MsgEditor", "Layout", Q_NULLPTR));
        m_tabWidgetMsg->setTabText(m_tabWidgetMsg->indexOf(Comment), QApplication::translate("MsgEditor", "Comment", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MsgEditor: public Ui_MsgEditor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MSGEDITOR_H
