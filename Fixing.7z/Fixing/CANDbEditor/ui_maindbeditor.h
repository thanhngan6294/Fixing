/********************************************************************************
** Form generated from reading UI file 'maindbeditor.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINDBEDITOR_H
#define UI_MAINDBEDITOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QWidget>
#include "edittablewidget.h"

QT_BEGIN_NAMESPACE

class Ui_MainDbEditor
{
public:
    QWidget *centralwidget;
    QTreeView *m_treeWidget;
    QStackedWidget *m_stackedWidget;
    QWidget *m_pageMsgs;
    editTableWidget *m_MsgsTableWidget;
    QWidget *m_pageSignals;
    editTableWidget *m_SignsTableWidget;
    QWidget *m_pageCom;
    editTableWidget *m_ComTableWidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainDbEditor)
    {
        if (MainDbEditor->objectName().isEmpty())
            MainDbEditor->setObjectName(QStringLiteral("MainDbEditor"));
        MainDbEditor->resize(856, 500);
        MainDbEditor->setContextMenuPolicy(Qt::NoContextMenu);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainDbEditor->setWindowIcon(icon);
        centralwidget = new QWidget(MainDbEditor);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        m_treeWidget = new QTreeView(centralwidget);
        m_treeWidget->setObjectName(QStringLiteral("m_treeWidget"));
        m_treeWidget->setGeometry(QRect(9, 9, 251, 441));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_treeWidget->sizePolicy().hasHeightForWidth());
        m_treeWidget->setSizePolicy(sizePolicy);
        m_treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);
        m_treeWidget->setHeaderHidden(true);
        m_stackedWidget = new QStackedWidget(centralwidget);
        m_stackedWidget->setObjectName(QStringLiteral("m_stackedWidget"));
        m_stackedWidget->setGeometry(QRect(271, 9, 576, 451));
        m_pageMsgs = new QWidget();
        m_pageMsgs->setObjectName(QStringLiteral("m_pageMsgs"));
        m_pageMsgs->setEnabled(true);
        m_MsgsTableWidget = new editTableWidget(m_pageMsgs);
        m_MsgsTableWidget->setObjectName(QStringLiteral("m_MsgsTableWidget"));
        m_MsgsTableWidget->setEnabled(true);
        m_MsgsTableWidget->setGeometry(QRect(0, 0, 561, 421));
        sizePolicy.setHeightForWidth(m_MsgsTableWidget->sizePolicy().hasHeightForWidth());
        m_MsgsTableWidget->setSizePolicy(sizePolicy);
        m_MsgsTableWidget->setMinimumSize(QSize(0, 0));
        m_MsgsTableWidget->setMaximumSize(QSize(16777215, 16777215));
        m_MsgsTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
        m_MsgsTableWidget->setEditTriggers(QAbstractItemView::AnyKeyPressed|QAbstractItemView::EditKeyPressed|QAbstractItemView::SelectedClicked);
        m_MsgsTableWidget->horizontalHeader()->setCascadingSectionResizes(false);
        m_MsgsTableWidget->horizontalHeader()->setProperty("showSortIndicator", QVariant(true));
        m_MsgsTableWidget->horizontalHeader()->setStretchLastSection(true);
        m_stackedWidget->addWidget(m_pageMsgs);
        m_pageSignals = new QWidget();
        m_pageSignals->setObjectName(QStringLiteral("m_pageSignals"));
        m_SignsTableWidget = new editTableWidget(m_pageSignals);
        m_SignsTableWidget->setObjectName(QStringLiteral("m_SignsTableWidget"));
        m_SignsTableWidget->setGeometry(QRect(0, 0, 561, 421));
        sizePolicy.setHeightForWidth(m_SignsTableWidget->sizePolicy().hasHeightForWidth());
        m_SignsTableWidget->setSizePolicy(sizePolicy);
        m_SignsTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
        m_SignsTableWidget->setEditTriggers(QAbstractItemView::AnyKeyPressed|QAbstractItemView::EditKeyPressed|QAbstractItemView::SelectedClicked);
        m_SignsTableWidget->horizontalHeader()->setCascadingSectionResizes(false);
        m_SignsTableWidget->horizontalHeader()->setProperty("showSortIndicator", QVariant(true));
        m_SignsTableWidget->horizontalHeader()->setStretchLastSection(true);
        m_stackedWidget->addWidget(m_pageSignals);
        m_pageCom = new QWidget();
        m_pageCom->setObjectName(QStringLiteral("m_pageCom"));
        m_ComTableWidget = new editTableWidget(m_pageCom);
        m_ComTableWidget->setObjectName(QStringLiteral("m_ComTableWidget"));
        m_ComTableWidget->setGeometry(QRect(0, 1, 561, 441));
        sizePolicy.setHeightForWidth(m_ComTableWidget->sizePolicy().hasHeightForWidth());
        m_ComTableWidget->setSizePolicy(sizePolicy);
        m_ComTableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
        m_ComTableWidget->setEditTriggers(QAbstractItemView::AnyKeyPressed|QAbstractItemView::EditKeyPressed|QAbstractItemView::SelectedClicked);
        m_ComTableWidget->setShowGrid(false);
        m_ComTableWidget->horizontalHeader()->setCascadingSectionResizes(false);
        m_ComTableWidget->horizontalHeader()->setProperty("showSortIndicator", QVariant(true));
        m_ComTableWidget->horizontalHeader()->setStretchLastSection(true);
        m_stackedWidget->addWidget(m_pageCom);
        MainDbEditor->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainDbEditor);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 856, 21));
        MainDbEditor->setMenuBar(menubar);
        statusbar = new QStatusBar(MainDbEditor);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainDbEditor->setStatusBar(statusbar);

        retranslateUi(MainDbEditor);

        m_stackedWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(MainDbEditor);
    } // setupUi

    void retranslateUi(QMainWindow *MainDbEditor)
    {
        MainDbEditor->setWindowTitle(QApplication::translate("MainDbEditor", "MainWindow", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainDbEditor: public Ui_MainDbEditor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINDBEDITOR_H
