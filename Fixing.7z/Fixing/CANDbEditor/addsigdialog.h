#ifndef ADDSIGDIALOG_H
#define ADDSIGDIALOG_H
#include <QTableWidget>
#include <QPushButton>
#include <QDialog>
#include "msgeditor.h"
class addSigDialog: public QDialog
{
    Q_OBJECT
public:
  explicit  addSigDialog(const MainDbEditor*editor, QWidget *parent = 0);
    QTableWidget * signal;
    QPushButton * addButt;
    QPushButton *canccelButt;
signals:
    addListSig2Mess(QVector<CANSignal*> listSig);
public slots:
    clickAddButton();
    clickCancelButton();
};

#endif // ADDSIGDIALOG_H
